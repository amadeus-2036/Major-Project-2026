import torch
import torchaudio
import torch.nn.functional as F
from CODE.config import SAMPLE_RATE, N_MELS

mel_transform = torchaudio.transforms.MelSpectrogram(
    sample_rate=SAMPLE_RATE,
    n_fft=1024,
    hop_length=512,
    n_mels=N_MELS
)

def process_chunk(chunk):
    waveform = torch.tensor(chunk).float().unsqueeze(0)

    mel = mel_transform(waveform)
    log_mel = torch.log(mel + 1e-9)

    log_mel = log_mel.unsqueeze(0)
    log_mel = F.interpolate(log_mel, size=(224, 224), mode='bilinear')
    log_mel = log_mel.squeeze(0)

    log_mel = log_mel.repeat(3, 1, 1)

    return log_mel